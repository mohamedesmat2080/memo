﻿#region

using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using API;
using API.Command;
using API.Database;
using API.Server;
using API.ServiceFactory;
using DuckSoup.Library;
using DuckSoup.Library.Commands;
using DuckSoup.Library.Event;
using DuckSoup.Library.Plugins;
using DuckSoup.Library.Server;
using DuckSoup.Library.Settings;
using DuckSoup.Library.Timers;
using log4net;
using log4net.Config;

#endregion

[assembly: XmlConfigurator(Watch = true)]

namespace DuckSoup;

public static class Program
{
    private static void Main()
    {
        var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
        XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

        //AppDomain.CurrentDomain.FirstChanceException += (sender, eventArgs) =>
        //{
        //    Global.Logger.Error($"Sender = {sender} Exception: {eventArgs.Exception.ToString()}");
        //};

        // prints out logo + version
        Global.Logger.InfoFormat("\n\n" +
                                 ",--.          .   .---.             \n" +
                                 "|   \\ . . ,-. | , \\___  ,-. . . ,-. \n" +
                                 "|   / | | |   |<      \\ | | | | | | \n" +
                                 "^--'  `-^ `-' ' ` `---' `-' `-^ |-' \n" +
                                 "                                |   \n" +
                                 "         Version  {0}         ' \n" +
                                 "\n",
        FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location)
                .ProductVersion);
        Console.Title = "Starting up...";
     
        var settingsManager = new SettingsManager();
        var databaseManager = new DatabaseManager();
        if (!databaseManager.CheckConnection())
        {
            Global.Logger.InfoFormat("Coudlnt connect to databsae");
        }


        var sharedObjects = new SharedObjects();
        var serverManager = new ServerManager();
        var commandManager = new CommandManager();
        var pluginManager = new PluginManager();
        var eventManager = new EventManager();
        var timerManager = new TimerManager();
        API.Models.GameServerManager.Start();

        // Make sure we start the command loop in order to not exit the application
        ServiceFactory.Load<ICommandManager>(typeof(ICommandManager)).StartCommandLoop();

    }

    public static void Stop()
    {
        ServiceFactory.Load<IServerManager>(typeof(IServerManager)).Dispose();
        ServiceFactory.Load<ICommandManager>(typeof(ICommandManager)).Dispose();
    }
}