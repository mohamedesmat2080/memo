using System.ComponentModel.DataAnnotations.Schema;

namespace API.Database.SRO_VT_SHARD
{
    [Table("_TimedJobForPet")]
    public partial class C_TimedJobForPet
    {
        public int ID { get; set; }

        public int CharID { get; set; }

        public byte Category { get; set; }

        public int JobID { get; set; }

        public int TimeToKeep { get; set; }

        public int? Data1 { get; set; }

        public int? Data2 { get; set; }

        public int? Data3 { get; set; }

        public int? Data4 { get; set; }

        public int? Data5 { get; set; }

        public int? Data6 { get; set; }

        public int? Data7 { get; set; }

        public int? Data8 { get; set; }

        public long Serial64 { get; set; }

        public int? JID { get; set; }
    }
}
