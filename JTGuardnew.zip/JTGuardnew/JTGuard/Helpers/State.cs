﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SilkroadSecurityAPI;

namespace JTGuard.Helpers
{
    public class State : IState
    {
        public LifeState? LifeState { get; set; }
        public MotionState? MotionState { get; set; }
        public MovementType? MovementType { get; set; }
        public BodyState? BodyState { get; set; }
        public PvpState? PvpState { get; set; }
        public BattleState BattleState { get; set; } = BattleState.InPeace;
        public ScrollState ScrollState { get; set; } = ScrollState.Cancel;
        public PVPCape PvpCape { get; set; } = PVPCape.None;
        public float? WalkSpeed { get; set; }
        public float? RunSpeed { get; set; }
        public float? BerzerkSpeed { get; set; }
        //public List<SkillInfo> ActiveBuffs { get; } = new();
        public void Deserialize(Packet packet)
        {
            LifeState = (LifeState)packet.ReadUInt8();
            packet.ReadUInt8(); //unkByte0
            MotionState = (MotionState)packet.ReadUInt8();
            BodyState = (BodyState)packet.ReadUInt8();
            WalkSpeed = packet.ReadFloat();
            RunSpeed = packet.ReadFloat();
            BerzerkSpeed = packet.ReadFloat();

            //var buffCount = packet.ReadUInt8();
            //for (var i = 0; i < buffCount; i++)
            //{
            //    var id = packet.ReadUInt32();
            //    var token = packet.ReadUInt32();

            //    var buff = new SkillInfo(id, token);
            //    if (buff.Record == null)
            //     continue;

            //    if (buff.Record.ParamsContains(1701213281))
            //     packet.ReadBool(); //IsCreator

            //    ActiveBuffs.Add(buff);
            //}
        }
    }
}
