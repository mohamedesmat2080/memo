#pragma once

class CShopItemStockPeriod
{

};