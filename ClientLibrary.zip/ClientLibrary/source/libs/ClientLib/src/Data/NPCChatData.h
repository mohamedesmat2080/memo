#pragma

class CNPCChatData
{

};