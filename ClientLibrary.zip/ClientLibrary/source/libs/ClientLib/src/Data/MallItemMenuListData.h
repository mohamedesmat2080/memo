#pragma once

class CMallItemMenuListData
{

};