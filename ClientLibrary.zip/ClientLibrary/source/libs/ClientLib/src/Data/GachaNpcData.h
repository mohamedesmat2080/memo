#pragma once

class CGachaNpcData
{

};