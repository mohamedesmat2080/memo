#pragma once

class CTeleportBuilding
{

};