#pragma once

class CMessageTipData
{

};