#pragma once

class CNPCPosData
{

};