#pragma once

class CShopItemStockQuantity
{

};