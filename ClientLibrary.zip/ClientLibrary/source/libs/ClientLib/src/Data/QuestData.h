#pragma once

class CQuestData
{

};