#pragma once

class CTeleportLink
{

};